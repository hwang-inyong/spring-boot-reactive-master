package com.hiy.hackingspringboot.reactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackingSpringBootCh1ReactiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
