package com.hiy.hackingspringboot.reactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackingSpringBootCh1ReactiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackingSpringBootCh1ReactiveApplication.class, args);
	}

}
